package com.systemcolor.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("system_color", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 56, 42, 32)
            setBackgroundColor(Color.rgb(12, 13, 24))
        }
        fun heading(text: String, size: Float): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(92, 237, 244))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(heading("SYSTEM COLOR", 30f))
        root.addView(heading("GAMER DISPLAY CONTROL • ALPHA", 12f))
        val youtube = Switch(this).apply {
            text = "YouTube Mode — preferência automática"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("youtube_auto", true)
            setOnCheckedChangeListener { _, enabled -> prefs.edit().putBoolean("youtube_auto", enabled).apply() }
        }
        root.addView(youtube)
        val intensity = heading("Intensidade configurada: ${prefs.getInt("intensity", 45)}%", 17f)
        root.addView(intensity)
        root.addView(SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("intensity", 45)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                    intensity.text = "Intensidade configurada: $value%"
                    if (fromUser) prefs.edit().putInt("intensity", value).apply()
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        })
        root.addView(heading("Prévia de configurações. Filtros globais e detecção de apps ainda não implementados.", 14f))
        setContentView(root)
    }
}
