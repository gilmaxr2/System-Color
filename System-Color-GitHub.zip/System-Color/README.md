# System Color

Projeto Android Kotlin — versão inicial 0.1.0-alpha.

## Estado atual
Tela de configurações com estilo escuro, preferência de YouTube Mode (ligada por padrão) e intensidade persistente (45% por padrão). **Ainda não aplica filtros na tela nem detecta automaticamente o YouTube.**

## Compilação
No GitHub: Actions → Build Android APK → Run workflow. Depois abra a execução e baixe o artefato `System-Color-debug-apk`.

Localmente, com JDK 17, Android SDK 35 e Gradle 8.9 instalados: `gradle :app:assembleDebug`.

O APK debug é assinado com chave de desenvolvimento e não é uma versão de produção.
